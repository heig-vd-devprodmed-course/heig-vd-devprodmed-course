<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VoitureController;

Route::get('/', function () {
    return redirect('/voitures');
});

Route::resource('voitures', VoitureController::class, ['except'=>['show','update']]);

Route::get('voitures/{idVoiture}/accessoires/{idAccessoire}', [VoitureController::class, 'destroy']);

