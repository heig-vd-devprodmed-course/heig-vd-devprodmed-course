<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('accessoire_voiture', function (Blueprint $table) {
            $table->id();
            $table->integer('accessoire_id')->unsigned();
            $table->integer('voiture_id')->unsigned();
            $table->foreign('accessoire_id')->references('id')->on('accessoires')
                    ->onDelete('restrict')
                    ->onUpdate('restrict');
            $table->foreign('voiture_id')->references('id')->on('voitures')
                    ->onDelete('restrict')
                    ->onUpdate('restrict');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('accessoire_voiture');
    }
};
