<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use DB;
use App\Models\Voiture;

class VoituresTableSeeder extends Seeder
{
    const NB_VOITURES = 10;
    
    private function randColor() {
        $color = ["rouge", "bleue", "verte", "noire", "blanche"];
        return $color[rand(0, count($color)-1)];
    }

    private function randType() {
        $type = ["break", "limousine", "SUV", "sport", "berline"];
        return $type[rand(0, count($type)-1)];
    }

    private function randMarque() {
        $marque = ["Toyota", "Seat", "BMW", "Audi", "Ferrari"];
        return $marque[rand(0, count($marque)-1)];
    }
    
    public function randCylindree() {
        return rand(1, 3) . ',' . rand(0,9);
    }
	
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('voitures')->delete();
        for ($i = 1; $i <= VoituresTableSeeder::NB_VOITURES; $i++) {
            Voiture::create([
                'marque' => $this->randMarque(),
                'type' => $this->randType(),
                'couleur' => $this->randColor(),
                'cylindree' => $this->randCylindree()
            ]);
        }
    }
}
