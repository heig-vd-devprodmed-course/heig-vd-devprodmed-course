<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Accessoire;

class AccessoiresTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Accessoire::create([
            'nom' => 'autoradio',
            'url' => 'autoradio']
        );
        Accessoire::create([
            'nom' => 'kit main libre',
            'url' => urlencode('kit main libre')]
        );
        Accessoire::create([
            'nom' => 'navigateur gps',
            'url' => urlencode('navigateur gps')]
        );
        Accessoire::create([
            'nom' => 'écran passagers',
            'url' => urlencode('écran passagers')]
        );
    }
}
