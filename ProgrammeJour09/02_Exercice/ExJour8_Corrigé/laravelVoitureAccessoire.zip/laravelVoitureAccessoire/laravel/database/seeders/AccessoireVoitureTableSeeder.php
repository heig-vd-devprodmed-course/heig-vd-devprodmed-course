<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Voiture;
use App\Models\Accessoire;

class AccessoireVoitureTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 1; $i <= VoituresTableSeeder::NB_VOITURES; $i++) {
            $numbers = range(1, 4);
            shuffle($numbers);
            $nbMaxAccessoires = rand(1, 3); // entre 1 et 3 accessoires par voitures
            for ($j = 1; $j <= $nbMaxAccessoires; $j++) {
				$voiture = Voiture::find($i);
				$voiture->accessoires()->attach($numbers[$j]);
				//DB::table('accessoire_voiture')->insert([
				//          'voiture_id' => $i,
				//          'accessoire_id' => $numbers[$j]]
				//);
            }
        }
    }
}
