<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Voiture;

class Accessoire extends Model
{
    use HasFactory;
	
	public $timestamps = false;
    
    protected $fillable=['nom','url'];
    
    public function voitures() {
        return $this->belongsToMany(Voiture::class);
    }
}
