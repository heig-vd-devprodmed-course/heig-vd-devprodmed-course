<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Accessoire;

class Voiture extends Model
{
    use HasFactory;
	
	public $timestamps = false;
    
    protected $fillable=['marque','type','couleur','cylindree'];
    
    public function accessoires() {
        return $this->belongsToMany(Accessoire::class);
    }
}
