<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Voiture;
use App\Models\Accessoire;

class VoitureController extends Controller
{
	protected $nbVoituresParPage = 10;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $voitures = Voiture::orderBy('voitures.marque', 'asc')
                ->paginate($this->nbVoituresParPage);
        $links = $voitures->render();
        return view('view_liste_voitures', compact('voitures', 'links'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('view_ajoute_voiture');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $voiture=Voiture::find($request->voitureId);   
        $voiture->accessoires()->detach();
        $voiture->accessoires()->attach($request->accessoiresIds);
        return redirect('/voitures');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $idVoiture)
    {
        $voiture = Voiture::findOrFail($idVoiture);
        $accessoires = Accessoire::all();
        $accessoiresVoiture = $voiture->accessoires()->get();
		foreach ($accessoires as $accessoire) {
            $checked[] = $accessoiresVoiture->contains($accessoire) ? "checked" : " ";
        }
        return view('view_ajoute_accessoire')->with(['voiture' => $voiture, 
            'accessoires' => $accessoires,
            'checked' => $checked]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $idVoiture, string $idAccessoire)
    {
        $voiture = Voiture::findOrFail($idVoiture);
        $accessoire = Accessoire::findOrFail($idAccessoire);
        $voiture->accessoires()->detach($accessoire->id);
        return redirect()->back();
    }
}
